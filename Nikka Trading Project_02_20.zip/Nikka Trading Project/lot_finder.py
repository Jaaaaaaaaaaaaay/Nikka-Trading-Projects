from flask import Flask, render_template, request, jsonify
import pandas as pd
import os
import warnings

app = Flask(__name__)

# Paths to the provided data files
LOT_DATA_FILE_PATH = "EPA - CIM Monitoring for lot.csv"
DISPATCH_FILE_PATH = "EPA - CIM Monitoring for Dispatch.xlsx"

def load_dispatch_data(file_path):
    try:
        df = pd.read_excel(file_path, dtype=str)


        # Rename columns
        df.rename(columns={
            'DISPATCHED DOCUMENTS': 'region_name',
            'Unnamed: 1': 'division_name',
            'Unnamed: 2': 'school_id',
            'Unnamed: 3': 'school_name',
            'Unnamed: 4': 'dispatched_date',
            'Unnamed: 5': 'plan_batch_no'
        }, inplace=True)

        # Convert 'dispatched_date' to datetime
        df['dispatched_date'] = pd.to_datetime(df['dispatched_date'], errors='coerce')



        return df.dropna(subset=['dispatched_date'])
    except Exception as e:
        
        return pd.DataFrame()


# Load and clean the lot data
def load_and_clean_lot_data(file_path):
    try:
        df = pd.read_csv(file_path, on_bad_lines='skip')
        df = df[['region_name', 'division_name', 'school_id', 'school_name', 'allocated_lots_numbers']].dropna()

        def clean_lot_numbers(value):
            if pd.isna(value):
                return ''
            numbers = [num.strip()[-2:] if num.strip().isdigit() and len(num.strip()) >= 4 else num.strip() for num in value.split(',')]
            return ', '.join(filter(str.isdigit, numbers))

        df['allocated_lots_numbers'] = df['allocated_lots_numbers'].apply(clean_lot_numbers)
        return df
    except Exception as e:
        
        return pd.DataFrame()

# Load data at startup
dispatch_df = load_dispatch_data(DISPATCH_FILE_PATH)
df = load_and_clean_lot_data(LOT_DATA_FILE_PATH)

# Global list to store selected school IDs
selected_schools = []

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/input', methods=['GET', 'POST'])
def input_data():
    if request.method == 'POST':
        school_id = request.form['school_id'].strip()
        school_name = request.form['school_name'].strip()

        # Filter based on provided inputs
        if school_id and school_name:
            filtered_df = df[(df['school_id'].astype(str) == school_id) & (df['school_name'].str.lower() == school_name.lower())]
        elif school_id:
            filtered_df = df[df['school_id'].astype(str) == school_id]
        elif school_name:
            filtered_df = df[df['school_name'].str.lower() == school_name.lower()]
        else:
            return render_template('input.html', result="Please enter a School ID or School Name.")

        if not filtered_df.empty:
            row = filtered_df.iloc[0]
            lot_numbers = row['allocated_lots_numbers']
            region_name = row['region_name']
            division_name = row['division_name']
            return render_template('match_result.html', school_id=row['school_id'], school_name=row['school_name'], lots=lot_numbers, region_name=region_name, division_name=division_name)
        else:
            return render_template('input.html', result="No matching data found.")
    return render_template('input.html')

@app.route('/search_dispatch', methods=['GET', 'POST'])
def search_dispatch():
    global dispatch_df  # Ensure we're always using the latest DataFrame

    if request.method == 'POST':
        # Get user-selected filters
        start_date_input = request.form.get('start_date', '')
        end_date_input = request.form.get('end_date', '')
        search_school_id = request.form.get('search_school_id', '').strip()
        search_school_name = request.form.get('search_school_name', '').strip().lower()
        plan_batch_no = request.form.get('plan_batch_no', '').strip()
        region_name = request.form.get('region_name', '').strip()
        division_name = request.form.get('division_name', '').strip()

        # Validate date inputs
        if not start_date_input:
            return render_template('search_dispatch.html', result="Please select a start date.")
        else:
            start_date = pd.to_datetime(start_date_input).date()

        end_date = pd.to_datetime(end_date_input).date() if end_date_input else start_date

        # Filter data dynamically
        # Ensure dispatched_date is converted to date type before filtering
        dispatch_df['dispatched_date'] = pd.to_datetime(dispatch_df['dispatched_date']).dt.date

        date_filtered = dispatch_df[
            (dispatch_df['dispatched_date'] >= start_date) & 
            (dispatch_df['dispatched_date'] <= end_date)
        ]

        # Apply additional filters
        if search_school_id:
            date_filtered = date_filtered[date_filtered['school_id'].astype(str) == search_school_id]
        if search_school_name:
            date_filtered = date_filtered[
                date_filtered['school_name'].str.lower().str.contains(search_school_name, na=False)
            ]
        if plan_batch_no:
            date_filtered = date_filtered[date_filtered['plan_batch_no'].astype(str) == plan_batch_no]
        if region_name:
            date_filtered = date_filtered[date_filtered['region_name'] == region_name]
        if division_name:
            date_filtered = date_filtered[date_filtered['division_name'] == division_name]

        # Ensure available filters update dynamically
        available_regions = sorted(date_filtered['region_name'].dropna().unique().tolist())
        available_divisions = sorted(date_filtered['division_name'].dropna().unique().tolist())
        available_batches = sorted(date_filtered['plan_batch_no'].dropna().unique().tolist())

        # Convert final filtered data to a list of records for the table
        dispatch_records = date_filtered[
            ['region_name', 'division_name', 'school_id', 'school_name', 'dispatched_date', 'plan_batch_no']
        ].dropna().to_dict(orient='records')

        return render_template(
            'search_dispatch.html',
            start_date=start_date,
            end_date=end_date,
            dispatch_records=dispatch_records,
            search_school_id=search_school_id,
            search_school_name=search_school_name,
            plan_batch_no=plan_batch_no,
            region_name=region_name,
            division_name=division_name,
            region_options=available_regions,
            division_options=available_divisions,
            plan_batch_options=available_batches
        )

    return render_template('search_dispatch.html')



@app.route('/check_lot_availability', methods=['GET', 'POST'])
def check_lot_availability():
    global selected_schools

    if not selected_schools:
        return render_template("lot_availability.html", lot_records=[], selected_schools=[], message="No schools selected.")

    # Merge dispatch and lot data on 'school_id'
    dispatch_df['school_id'] = dispatch_df['school_id'].astype(str)
    df['school_id'] = df['school_id'].astype(str)

    merged_df = pd.merge(dispatch_df, df, on="school_id", how="inner")


    # Filter based on selected school IDs
    filtered_df = merged_df[merged_df['school_id'].astype(str).isin(selected_schools)]

    if filtered_df.empty:
        return render_template("lot_availability.html", lot_records=[], selected_schools=selected_schools, message="No matching lot availability found.")

    # Extract relevant columns for display
    lot_records = filtered_df[['region_name_x', 'division_name_x', 'school_id', 'school_name_x', 'allocated_lots_numbers']].rename(
        columns={"region_name_x": "region_name", "division_name_x": "division_name", "school_name_x": "school_name"}
    ).to_dict(orient="records")

    return render_template(
        "lot_availability.html",
        lot_records=lot_records,
        selected_schools=selected_schools,
        message=None
    )


@app.route('/save_selected_schools', methods=['POST'])
def save_selected_schools():
    global selected_schools
    data = request.get_json()
    selected_ids = data.get('selected_schools', [])
    
    # Update the global list with selected schools
    selected_schools = selected_ids
    
    return jsonify({'status': 'success', 'count': len(selected_schools)})

@app.route('/clear_selections', methods=['POST'])
def clear_selections():
    global selected_schools
    selected_schools = []  # Clear the list
    return jsonify({'status': 'success'})

@app.route('/search_advanced', methods=['GET', 'POST'])
def search_advanced():
    global dispatch_df, df  # Use the global DataFrames

    if request.method == 'POST':
        # Get user-selected filters
        search_filters = {}
        plan_batch_no = request.form.get('plan_batch_no', '').strip()
        school_id = request.form.get('school_id', '').strip()
        school_name = request.form.get('school_name', '').strip().lower()
        start_date_input = request.form.get('start_date', '')
        end_date_input = request.form.get('end_date', '')
        region_name = request.form.get('region_name', '').strip()
        division_name = request.form.get('division_name', '').strip()

        # Ensure dispatched_date is converted to datetime format
        dispatch_df['dispatched_date'] = pd.to_datetime(dispatch_df['dispatched_date'], errors='coerce')

        # Ensure both `school_id` columns are strings before merging
        dispatch_df['school_id'] = dispatch_df['school_id'].astype(str)
        df['school_id'] = df['school_id'].astype(str)

        # Merge dispatch_df with df to include lot numbers
        merged_df = dispatch_df.merge(df[['school_id', 'allocated_lots_numbers']], on='school_id', how='left')

        # Apply filters dynamically
        if plan_batch_no:
            merged_df = merged_df[merged_df['plan_batch_no'].astype(str) == plan_batch_no].copy()
            search_filters["Plan Batch No"] = plan_batch_no
        if school_id:
            merged_df = merged_df[merged_df['school_id'].astype(str) == school_id].copy()
            search_filters["School ID"] = school_id
        if school_name:
            merged_df = merged_df[merged_df['school_name'].str.lower().str.contains(school_name, na=False)].copy()
            search_filters["School Name"] = school_name
        if start_date_input:
            start_date = pd.to_datetime(start_date_input).date()
            merged_df = merged_df[merged_df['dispatched_date'].dt.date >= start_date].copy()
            search_filters["Start Date"] = start_date_input
        if end_date_input:
            end_date = pd.to_datetime(end_date_input).date()
            merged_df = merged_df[merged_df['dispatched_date'].dt.date <= end_date].copy()
            search_filters["End Date"] = end_date_input
        if region_name:
            merged_df = merged_df[merged_df['region_name'] == region_name].copy()
            search_filters["Region"] = region_name
        if division_name:
            merged_df = merged_df[merged_df['division_name'] == division_name].copy()
            search_filters["Division"] = division_name

        # Convert filtered data to a list of records for rendering
        dispatch_records = merged_df[
            ['region_name', 'division_name', 'school_id', 'school_name', 'plan_batch_no', 'allocated_lots_numbers']
        ].fillna("").to_dict(orient='records')

        # Redirect to results page and pass search filters
        return render_template('search_results.html', dispatch_records=dispatch_records, search_filters=search_filters)

    return render_template(
        'search_advanced.html',
        plan_batch_no='',
        school_id='',
        school_name='',
        start_date='',
        end_date='',
        region_name='',
        division_name='',
        region_options=sorted(dispatch_df['region_name'].dropna().unique().tolist()),
        division_options=sorted(dispatch_df['division_name'].dropna().unique().tolist()),
        plan_batch_options=sorted(dispatch_df['plan_batch_no'].dropna().unique().tolist())
    )

if __name__ == '__main__':
    app.run(debug=True)